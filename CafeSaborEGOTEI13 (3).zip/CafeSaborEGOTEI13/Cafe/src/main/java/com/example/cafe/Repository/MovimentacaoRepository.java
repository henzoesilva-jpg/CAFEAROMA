package com.example.cafe.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.cafe.Model.MovimentacaoEstoque;

public interface MovimentacaoRepository extends JpaRepository<MovimentacaoEstoque, Long> {
}
