package com.example.cafe.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    /**
     * Configuração do SecurityFilterChain para autorização de requisições
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable()) // Desabilita CSRF para simplificar (em produção, habilitar)
                .authorizeHttpRequests(authz -> authz
                        .requestMatchers("/").permitAll() // Acesso público ao index
                        .requestMatchers("/style.css").permitAll() // Acesso público aos recursos estáticos
                        .anyRequest().authenticated() // Todas as outras requisições precisam de autenticação
                )
                .formLogin(form -> form
                        .loginPage("/") // Página de login customizada (index.html)
                        .loginProcessingUrl("/login") // URL para processar o login
                        .defaultSuccessUrl("/dashboard", true) // Redireciona para dashboard após login bem-sucedido
                        .failureUrl("/?error=true") // Redireciona em caso de falha
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/")
                        .permitAll()
                );

        return http.build();
    }

    /**
     * UserDetailsService com usuários em memória (In-Memory Authentication)
     */
    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails admin = User.builder()
                .username("admin")
                .password(passwordEncoder().encode("admin123"))
                .roles("ADMIN")
                .build();

        UserDetails user = User.builder()
                .username("usuario")
                .password(passwordEncoder().encode("senha123"))
                .roles("USER")
                .build();

        UserDetails gerente = User.builder()
                .username("gerente")
                .password(passwordEncoder().encode("gerente123"))
                .roles("MANAGER")
                .build();

        return new InMemoryUserDetailsManager(admin, user, gerente);
    }

    /**
     * Encoder de password - BCrypt
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}

