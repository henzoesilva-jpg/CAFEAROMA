package com.example.cafe.controller;

import com.example.cafe.Model.MovimentacaoEstoque;
import com.example.cafe.Model.Produto;
import com.example.cafe.Repository.MovimentacaoRepository;
import com.example.cafe.Repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/estoque")
public class EstoqueController {

    @Autowired
    private MovimentacaoRepository movimentacaoRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    @GetMapping
    public String listarMovimentacoes(Model model) {
        model.addAttribute("movimentacoes", movimentacaoRepository.findAll());
        return "estoque";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("movimentacao", new MovimentacaoEstoque());
        model.addAttribute("produtos", produtoRepository.findAll());
        return "estoque/movimentacao";
    }

    @PostMapping
    public String salvar(@ModelAttribute MovimentacaoEstoque movimentacao) {
        movimentacao.setDataMovimentacao(java.time.LocalDateTime.now());
        movimentacaoRepository.save(movimentacao);
        atualizarEstoqueProduto(movimentacao);
        return "redirect:/estoque";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        MovimentacaoEstoque movimentacao = movimentacaoRepository.findById(id).orElseThrow();
        model.addAttribute("movimentacao", movimentacao);
        model.addAttribute("produtos", produtoRepository.findAll());
        return "estoque/movimentacao";
    }

    @PostMapping("/atualizar/{id}")
    public String atualizar(@PathVariable Long id, @ModelAttribute MovimentacaoEstoque movimentacao) {
        movimentacao.setId(id);
        movimentacao.setDataMovimentacao(java.time.LocalDateTime.now());
        movimentacaoRepository.save(movimentacao);
        atualizarEstoqueProduto(movimentacao);
        return "redirect:/estoque";
    }

    @GetMapping("/deletar/{id}")
    public String deletar(@PathVariable Long id) {
        movimentacaoRepository.deleteById(id);
        return "redirect:/estoque";
    }

    private void atualizarEstoqueProduto(MovimentacaoEstoque movimentacao) {
        Produto produto = movimentacao.getProduto();
        if (produto != null) {
            int quantidade = movimentacao.getQuantidade() != null ? movimentacao.getQuantidade() : 0;
            if ("ENTRADA".equalsIgnoreCase(movimentacao.getTipo())) {
                produto.setQuantidadeEstoque((produto.getQuantidadeEstoque() != null ? produto.getQuantidadeEstoque() : 0) + quantidade);
            } else if ("SAIDA".equalsIgnoreCase(movimentacao.getTipo())) {
                produto.setQuantidadeEstoque((produto.getQuantidadeEstoque() != null ? produto.getQuantidadeEstoque() : 0) - quantidade);
            }
            produtoRepository.save(produto);
        }
    }
}